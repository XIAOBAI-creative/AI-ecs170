How to use these Stage 3 digit CNN files

1. Copy local_code/stage_3_code/* into your project folder:
   ECS170_Spring_2026_Source_Code_Template/local_code/stage_3_code/

2. Copy script/stage_3_script/script_digit_cnn.py into:
   ECS170_Spring_2026_Source_Code_Template/script/stage_3_script/

3. Put the handwritten digit dataset under:
   ECS170_Spring_2026_Source_Code_Template/data/stage_3_data/

4. Open script/stage_3_script/script_digit_cnn.py and change this line:
   data_obj.dataset_source_file_name = 'digit'
   to the real folder/file name after unzipping the Stage 3 dataset.

5. In PyCharm, set Working Directory to:
   ECS170_Spring_2026_Source_Code_Template/script/stage_3_script

6. Run:
   script_digit_cnn.py

Expected outputs:
- final printed accuracy
- result/stage_3_result/digit_cnn_prediction_result
- result/stage_3_result/digit_cnn_learning_curve.csv
- result/stage_3_result/digit_cnn_training_loss.png
- result/stage_3_result/digit_cnn_accuracy.png
