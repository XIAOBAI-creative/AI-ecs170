from local_code.stage_3_code.Dataset_Loader import Dataset_Loader
from local_code.stage_3_code.Method_CNN import Method_CNN
from local_code.stage_3_code.Result_Saver import Result_Saver
from local_code.stage_3_code.Setting_Train_Test_Split import Setting_Train_Test_Split
from local_code.stage_3_code.Evaluate_Accuracy import Evaluate_Accuracy
import numpy as np
import torch


if __name__ == '__main__':
    np.random.seed(2)
    torch.manual_seed(2)

    data_obj = Dataset_Loader('stage3 digit dataset', '')
    data_obj.dataset_source_folder_path = '../../data/stage_3_data/'

    # Change this after you unzip the Stage 3 dataset.
    # Examples:
    # data_obj.dataset_source_file_name = 'digit'
    # data_obj.dataset_source_file_name = 'MNIST'
    # data_obj.dataset_source_file_name = 'mnist.npz'
    # data_obj.dataset_source_file_name = 'digits.csv'
    data_obj.dataset_source_file_name = 'digit'

    # For handwritten digit data, grayscale 28x28 is usually correct.
    data_obj.image_size = (28, 28)
    data_obj.convert_gray = True
    data_obj.normalize = True

    method_obj = Method_CNN('convolutional neural network', '')
    method_obj.max_epoch = 20
    method_obj.learning_rate = 0.001
    method_obj.batch_size = 64
    method_obj.history_destination_folder_path = '../../result/stage_3_result/'

    result_obj = Result_Saver('saver', '')
    result_obj.result_destination_folder_path = '../../result/stage_3_result/'
    result_obj.result_destination_file_name = 'digit_cnn_prediction_result'

    setting_obj = Setting_Train_Test_Split('train test split', '')
    setting_obj.test_size = 0.2
    setting_obj.random_state = 2

    evaluate_obj = Evaluate_Accuracy('accuracy', '')

    print('************ Start Stage 3 Digit CNN ************')
    setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
    setting_obj.print_setup_summary()
    score, _ = setting_obj.load_run_save_evaluate()
    print('************ Overall Performance ************')
    print('Digit CNN Accuracy: ' + str(score))
    print('************ Finish ************')
